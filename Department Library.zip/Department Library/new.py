import os
import socket
import threading
import json
import logging
import random
import string
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import pandas as pd
from datetime import datetime, timedelta

from flask import Flask, render_template, request, jsonify, session, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from trie import Trie, create_books_trie
from encrypt import verify_password, hash_password

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask App
app = Flask(__name__)
CORS(app)  # Enable CORS for frontend requests

# Flask Session Configuration
app.secret_key = os.environ.get("SESSION_SECRET", "default-secret-key")

# Set the static folder to the current directory for serving static files
app.static_folder = os.path.abspath(os.path.dirname(__file__))

# PostgreSQL Database Configuration
app.config["SQLALCHEMY_DATABASE_URI"] = "postgresql://postgres:Rajini@localhost:5432/dept_lib"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize Database
db = SQLAlchemy(app)

# Store verification codes temporarily (in a real app, use Redis or a database)
verification_codes = {}

# Define Book Model
class Book(db.Model):
    __tablename__ = "books"

    BookID = db.Column(db.Text, primary_key=True)
    ISBN = db.Column(db.Text, nullable=True)
    Title = db.Column(db.Text, nullable=False)
    Author = db.Column(db.Text, nullable=False)
    Category = db.Column(db.Text, nullable=False)
    Publisher = db.Column(db.Text, nullable=True)
    Date_of_release = db.Column(db.DateTime, nullable=True)
    No_of_Pages = db.Column(db.BigInteger, nullable=True)
    No_of_copies = db.Column(db.BigInteger, nullable=True)
    Availability = db.Column(db.Text, nullable=False)
    Added_at = db.Column(db.DateTime, nullable=True)

def load_books_into_trie():
    books = Book.query.distinct(Book.Title, Book.Author).all()  # Fetch only unique books
    books_list = [
        {"title": book.Title, "author": book.Author, "year": book.Date_of_release.year if book.Date_of_release else None}
        for book in books
    ]
    return create_books_trie(books_list)

# Load Trie After App Context is Ready
with app.app_context():
    trie = load_books_into_trie()

# Helper functions for authentication
def generate_verification_code():
    """Generate a random 6-digit verification code"""
    return ''.join(random.choices(string.digits, k=6))

def send_verification_email(recipient_email, verification_code):
    """Send verification code to the user's email"""
    # Email configuration
    sender_email = "itlibrary377@gmail.com"  # TODO: Replace with your Gmail address
    password = "vgbg hynz qjgk qxoo"  # TODO: Replace with your app password
    
    # Create message
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = recipient_email
    message["Subject"] = "Password Reset Verification Code"
    
    # Email body
    body = f"""
    Hello,
    
    You have requested to reset your password. Use the following verification code to complete the process:
    
    {verification_code}
    
    If you did not request this, please ignore this email.
    
    Thank you,
    Department Library System
    """
    
    message.attach(MIMEText(body, "plain"))
    
    try:
        # Create SMTP session
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()  # Secure the connection
        
        # Login to email server
        server.login(sender_email, password)
        
        # Send email
        text = message.as_string()
        server.sendmail(sender_email, recipient_email, text)
        
        # Close connection
        server.quit()
        
        return True
    except Exception as e:
        logger.error(f"Error sending email: {str(e)}")
        return False

# ------------------------------------------------------
# BOOK MANAGEMENT ROUTES (from temp.py)
# ------------------------------------------------------

# Homepage Route
@app.route('/')
def loginpage():
    return render_template('Untitled-1.html')

@app.route('/home')
def index():
    return render_template('index.html')

# Alternative homepage for authentication system
@app.route('/auth-home')
def auth_home():
    # Serve the HTML file from the static folder
    return send_from_directory(app.static_folder, 'Untitled-1.html')

@app.route("/books", methods=["GET"])
def get_books():
    title = request.args.get("title", "").strip().lower()
    category = request.args.get("category", "").strip().lower()
    availability = request.args.get("availability", "").strip().lower()

    print(f"🔍 Received Filters - Title: {title}, Category: {category}, Availability: {availability}")  # Debugging

    query = Book.query

    if title:
        query = query.filter(Book.Title.ilike(f"%{title}%"))

    if category:
        query = query.filter(Book.Category.ilike(f"%{category}%"))

    if availability:
        if availability in ["available", "yes", "true", "1"]:
            query = query.filter(Book.Availability.ilike("%yes%"))  # Matches "yes"
        elif availability in ["borrowed", "no", "false", "0"]:
            query = query.filter(Book.Availability.ilike("%no%"))   # Matches "no"

    books = query.all()

    print(f"📚 Books found: {len(books)}")  # Debugging

    books_list = [{
        "BookID": b.BookID,
        "ISBN": b.ISBN,
        "title": b.Title,
        "author": b.Author,
        "category": b.Category,
        "publisher": b.Publisher,
        "date_of_release": b.Date_of_release.isoformat() if b.Date_of_release else None,
        "no_of_pages": b.No_of_Pages,
        "no_of_copies": b.No_of_copies,
        "availability": "Available" if b.Availability.strip().lower() in ["yes", "available", "true", "1"] else "Borrowed",
        "added_at": b.Added_at.isoformat() if b.Added_at else None
    } for b in books]

    return jsonify(books_list)

@app.route("/books/search", methods=["GET"])
def search_book():
    title = request.args.get("title", "").strip()

    if not title:
        return jsonify({"message": "Please provide a book title"}), 400

    # Fetch books with case-insensitive title matching
    books = (
        Book.query.filter(Book.Title.ilike(title))
        .order_by(Book.BookID)  # Ensuring consistent order
        .all()
    )

    # Remove duplicates (ignore case)
    unique_books = {}
    for book in books:
        lower_title = book.Title.lower()
        if lower_title not in unique_books:
            unique_books[lower_title] = book  # Store only one entry per title

    # Convert to JSON format
    result = [{
        "BookID": book.BookID,
        "ISBN": book.ISBN,
        "title": book.Title,
        "author": book.Author,
        "category": book.Category,
        "publisher": book.Publisher,
        "date_of_release": book.Date_of_release.isoformat() if book.Date_of_release else None,
        "no_of_pages": book.No_of_Pages,
        "no_of_copies": book.No_of_Copies,
        "availability": book.Availability,
        "added_at": book.Added_at.isoformat() if book.Added_at else None
    } for book in unique_books.values()]

    if result:
        return jsonify(result)
    
    return jsonify({"message": "Book not found"}), 404

# Book Suggestion Endpoint Using Trie
@app.route('/suggest')
def suggest():
    prefix = request.args.get('prefix', '').lower()
    if not prefix:
        return jsonify([])
    suggestions = trie.search(prefix)
    return jsonify(suggestions)

# View Cart
@app.route('/cart')
def cart():
    cart_items = session.get('cart', [])
    return render_template('cart.html', cart_items=cart_items, cart_count=len(cart_items))

@app.route('/cart/add', methods=['POST'])
def add_to_cart():
    try:
        book = request.get_json()
        print("📥 Received book data:", book)  # Debugging

        if not book:
            return jsonify({"error": "No book data received"}), 400

        # Ensure session['cart'] is a list
        if 'cart' not in session:
            session['cart'] = []

        # Convert to list if it's a string (Fix for TypeError)
        if isinstance(session['cart'], str):
            try:
                session['cart'] = json.loads(session['cart'])
            except json.JSONDecodeError as e:
                print("🔥 JSON decode error:", e)  # Debugging
                session['cart'] = []

        cart_items = session['cart']

        # Ensure it's a list
        if not isinstance(cart_items, list):
            print("🔥 Cart is not a list:", cart_items)  # Debugging
            return jsonify({"error": "Cart data is corrupted"}), 500

        # Use `dict()` safely instead of assuming it's an object
        if not any(item.get('title') == book.get('title') for item in cart_items):
            cart_items.append(book)
            session['cart'] = cart_items  # Now it's a list, not a string
            session.modified = True

            return jsonify({"message": "Book added to cart", "cart_count": len(cart_items)})

        return jsonify({"message": "Book already in cart", "cart_count": len(cart_items)})

    except Exception as e:
        print("🔥 Error in /cart/add:", str(e))  # Debugging
        return jsonify({"error": "Internal server error", "details": str(e)}), 500

# Get Cart Items
@app.route('/cart', methods=['GET'])
def get_cart():
    cart_items = session.get('cart', [])
    return jsonify({"cart": cart_items, "cart_count": len(cart_items)})

# Remove a Book from Cart
@app.route('/cart/remove', methods=['POST'])
def remove_from_cart():
    book = request.get_json()
    if not book:
        return jsonify({"error": "No book data provided"}), 400

    cart_items = session.get('cart', [])
    cart_items = [item for item in cart_items if item['title'] != book['title']]
    session['cart'] = cart_items
    return jsonify({"message": "Book removed from cart", "cart_count": len(cart_items)})

# Checkout Cart
@app.route('/cart/checkout', methods=['POST'])
def checkout():
    cart_items = session.get('cart', [])
    if not cart_items:
        return jsonify({"error": "Cart is empty"}), 400

    expiry_time = datetime.now() + timedelta(days=1)
    receipt = {
        "books": cart_items,
        "expiry_time": expiry_time.isoformat(),
        "reservation_time": datetime.now().isoformat()
    }

    session['cart'] = []
    return jsonify(receipt)

# ------------------------------------------------------
# AUTHENTICATION ROUTES (from server.py)
# ------------------------------------------------------

@app.route('/verify-login', methods=['POST'])
def verify_login():
    try:
        login_data = request.get_json()
        
        # Debug print the received data
        logger.debug(f"Received login data: {login_data}")
        
        # Use raw string for Windows path
        excel_path = r"templates\department_library_users.xlsx"
        
        logger.debug(f"Attempting to read Excel file from: {excel_path}")
        
        # Check if file exists
        if not os.path.exists(excel_path):
            logger.error(f"Excel file not found at: {excel_path}")
            return jsonify({"detail": "Excel file not found"}), 404
        
        # Read the Excel file
        try:
            df = pd.read_excel(excel_path)
            logger.debug(f"Excel file read successfully. Columns: {df.columns.tolist()}")
            logger.debug(f"First few rows: {df.head().to_dict()}")
        except Exception as excel_error:
            logger.error(f"Error reading Excel file: {str(excel_error)}")
            return jsonify({"detail": f"Error reading Excel file: {str(excel_error)}"}), 500

        # Clean the data
        df['Email ID'] = df['Email ID'].astype(str).str.strip()
        email = login_data.get('email', '').strip()
        password = login_data.get('password', '').strip()
        
        logger.debug(f"Searching for email: {email}")
        
        # First find the user by email
        user = df[df['Email ID'] == email]
        
        logger.debug(f"Found user records: {len(user)}")
        
        if not user.empty:
            # Get the stored hash for this user
            stored_hash = user.iloc[0]['Password']
            logger.debug("Found stored hash for user")
            
            # Verify the password
            is_valid = verify_password(stored_hash, password)
            logger.debug(f"Password verification result: {is_valid}")
            
            if is_valid:
                logger.info(f"Successful login attempt for email: {email}")
                return jsonify({"status": "success", "message": "Login successful"})
        
        logger.warning(f"Failed login attempt for email: {email}")
        return jsonify({"detail": "Invalid credentials"}), 401
            
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        logger.error(f"Error type: {type(e)}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"detail": f"Server error: {str(e)}"}), 500

@app.route('/send-verification-code', methods=['POST'])
def send_verification_code():
    try:
        data = request.get_json()
        email = data.get('email', '').strip()
        
        if not email:
            return jsonify({"detail": "Email is required"}), 400
        
        # Check if email exists in the database
        excel_path = r"templates\department_library_users.xlsx"
        
        if not os.path.exists(excel_path):
            logger.error(f"Excel file not found at: {excel_path}")
            return jsonify({"detail": "Excel file not found"}), 404
        
        df = pd.read_excel(excel_path)
        df['Email ID'] = df['Email ID'].astype(str).str.strip()
        
        # Find the user by email
        user = df[df['Email ID'] == email]
        
        if user.empty:
            logger.warning(f"Email not found for verification: {email}")
            return jsonify({"detail": "Email not found"}), 404
        
        # Generate verification code
        verification_code = generate_verification_code()
        
        # Store verification code
        verification_codes[email] = verification_code
        
        # Send verification email
        email_sent = send_verification_email(email, verification_code)
        
        if email_sent:
            logger.info(f"Verification code sent to: {email}")
            return jsonify({"status": "success", "message": "Verification code sent"})
        else:
            logger.error(f"Failed to send verification email to: {email}")
            return jsonify({"detail": "Failed to send verification email"}), 500
            
    except Exception as e:
        logger.error(f"Unexpected error in send_verification_code: {str(e)}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"detail": f"Server error: {str(e)}"}), 500

@app.route('/verify-code', methods=['POST'])
def verify_code():
    try:
        data = request.get_json()
        email = data.get('email', '').strip()
        code = data.get('verification_code', '').strip()
        
        if not email or not code:
            return jsonify({"detail": "Email and verification code are required"}), 400
        
        # Check if the verification code matches
        stored_code = verification_codes.get(email)
        
        if not stored_code or stored_code != code:
            logger.warning(f"Invalid verification code for: {email}")
            return jsonify({"detail": "Invalid verification code"}), 400
        
        # Code is valid
        logger.info(f"Verification code validated for: {email}")
        return jsonify({"status": "success", "message": "Verification successful"})
        
    except Exception as e:
        logger.error(f"Unexpected error in verify_code: {str(e)}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"detail": f"Server error: {str(e)}"}), 500

@app.route('/reset-password', methods=['POST'])
def reset_password():
    try:
        reset_data = request.get_json()
        
        # Debug print the received data
        logger.debug(f"Received password reset data: {reset_data}")
        
        # Get email, new password, and verification code from request
        email = reset_data.get('email', '').strip()
        new_password = reset_data.get('new_password', '').strip()
        verification_code = reset_data.get('verification_code', '').strip()
        
        if not email or not new_password or not verification_code:
            return jsonify({"detail": "Email, new password, and verification code are required"}), 400
        
        # Verify the code
        stored_code = verification_codes.get(email)
        if not stored_code or stored_code != verification_code:
            logger.warning(f"Invalid verification code for password reset: {email}")
            return jsonify({"detail": "Invalid verification code"}), 400
        
        # Code is valid, proceed with password reset
        # Use raw string for Windows path
        excel_path = r"templates\department_library_users.xlsx"
        
        logger.debug(f"Attempting to read Excel file from: {excel_path}")
        
        # Check if file exists
        if not os.path.exists(excel_path):
            logger.error(f"Excel file not found at: {excel_path}")
            return jsonify({"detail": "Excel file not found"}), 404
        
        try:
            # Read the Excel file
            df = pd.read_excel(excel_path)
            logger.debug(f"Excel file read successfully for password reset")
            
            # Clean the data
            df['Email ID'] = df['Email ID'].astype(str).str.strip()
            
            # Find the user by email
            user_mask = df['Email ID'] == email
            
            if not any(user_mask):
                logger.warning(f"Email not found for password reset: {email}")
                return jsonify({"detail": "Email not found"}), 404
            
            # Hash the new password
            hashed_password = hash_password(new_password)
            
            # Update the password for this user
            df.loc[user_mask, 'Password'] = hashed_password
            
            # Save the updated DataFrame back to Excel
            df.to_excel(excel_path, index=False)
            
            # Remove the used verification code
            if email in verification_codes:
                del verification_codes[email]
            
            logger.info(f"Password successfully reset for email: {email}")
            return jsonify({"status": "success", "message": "Password reset successful"})
            
        except Exception as excel_error:
            logger.error(f"Error updating Excel file: {str(excel_error)}")
            return jsonify({"detail": f"Error updating Excel file: {str(excel_error)}"}), 500
            
    except Exception as e:
        logger.error(f"Unexpected error in password reset: {str(e)}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"detail": f"Server error: {str(e)}"}), 500

# ------------------------------------------------------
# SERVER FUNCTIONS
# ------------------------------------------------------

def tcp_server():
    host = '0.0.0.0'
    port = 8000  # Using port 8000 as in the original files
    
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(5)
    
    print(f"TCP Server is running on port {port}")
    
    while True:
        client_socket, addr = server_socket.accept()
        print(f"Connection from {addr}")
        client_socket.send(b"Hello from TCP Server")
        client_socket.close()

def run_flask():
    app.run(debug=True, port=5000)  # Run Flask on port 5000 to avoid conflict with TCP server

# Main execution
if __name__ == '__main__':
    # Start Flask server in a thread
    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()
    
    # Start TCP server in the main thread
    tcp_server() 