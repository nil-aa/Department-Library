import os 
from flask import Flask, render_template, request, jsonify, session, redirect, url_for,flash
import json
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from trie import Trie, create_books_trie
from datetime import datetime, timedelta
import pandas as pd
import logging
from encrypt import verify_password, hash_password
import random
import sqlite3
import string
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import text, or_
import uuid
from email.message import EmailMessage

# ✅ Initialize Flask App
app = Flask(__name__)
CORS(app)  # Enable CORS for frontend requests

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# ✅ Flask Session Configuration
app.secret_key = os.environ.get("SESSION_SECRET", "default-secret-key")

# ✅ PostgreSQL Database Configuration
DB_USER = os.environ.get("DB_USER", "postgres")
DB_PASSWORD = os.environ.get("DB_PASSWORD", "Rajini")  # Default password from your connection string
DB_HOST = os.environ.get("DB_HOST", "localhost")
DB_PORT = os.environ.get("DB_PORT", "5432")
DB_NAME = os.environ.get("DB_NAME", "dept_lib")

app.config["SQLALCHEMY_DATABASE_URI"] = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# ✅ Initialize Database
db = SQLAlchemy(app)

static_dir = os.path.join(os.path.dirname(__file__), 'static')
if not os.path.exists(static_dir):
    os.makedirs(static_dir)
    print(f"Created static directory: {static_dir}")

# Add this near the top of your file, after app = Flask(__name__)
# Ensure static directory exists
static_dir = os.path.join(os.path.dirname(__file__), 'static')
if not os.path.exists(static_dir):
    os.makedirs(static_dir)
    print(f"Created static directory: {static_dir}")

def load_sql_file(file_path):
    try:
        # Convert to absolute path if it's not already
        abs_path = os.path.abspath(file_path)
        if not os.path.exists(abs_path):
            print(f"Warning: File not found - {abs_path}")
            return []
        
        print(f"Loading SQL file: {abs_path}")
        
        # Create a temporary SQLite database in memory
        conn = sqlite3.connect(':memory:')
        
        # Read and execute the SQL file
        with open(abs_path, 'r') as sql_file:
            sql_script = sql_file.read()
            conn.executescript(sql_script)
        
        # Query the data
        df = pd.read_sql_query("SELECT * FROM mytable", conn)
        
        # Convert date columns from Excel serial numbers to datetime
        date_columns = ['Borrow Date', 'Due Date', 'Return Date']
        for col in date_columns:
            if col in df.columns:
                # Convert Excel serial numbers to datetime
                df[col] = pd.to_datetime('1899-12-30') + pd.to_timedelta(df[col], unit='D')
                df[col] = df[col].dt.strftime('%Y-%m-%d')
        
        records = df.to_dict(orient='records')
        print(f"Successfully loaded {len(records)} records from {os.path.basename(abs_path)}")
        return records
    except Exception as e:
        print(f"Error loading {file_path}: {str(e)}")
        return []

# Update the file path functions to use the correct file names
def due1_books():
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "lib_transactions.sql")
    data = load_sql_file(file_path)
    if not data:
        # Provide sample data if SQL file is not found
        today = datetime.now().strftime('%Y-%m-%d')
        yesterday = (datetime.now() - pd.Timedelta(days=1)).strftime('%Y-%m-%d')
        next_week = (datetime.now() + pd.Timedelta(days=7)).strftime('%Y-%m-%d')
        last_week = (datetime.now() - pd.Timedelta(days=7)).strftime('%Y-%m-%d')
        
        data = [
            {'Transaction ID': 'T001', 'User ID': 'U001', 'Book ID': 'B001', 'Borrow Date': yesterday, 'Due Date': next_week, 'Return Date': None, 'Fines': 0},
            {'Transaction ID': 'T002', 'User ID': 'U002', 'Book ID': 'B002', 'Borrow Date': last_week, 'Due Date': yesterday, 'Return Date': None, 'Fines': 50},
            {'Transaction ID': 'T003', 'User ID': 'U001', 'Book ID': 'B003', 'Borrow Date': last_week, 'Due Date': yesterday, 'Return Date': today, 'Fines': 0}
        ]
    return data

def load_books():
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "lib_books.sql")
    data = load_sql_file(file_path)
    if not data:
        # Provide sample data if SQL file is not found
        data = [
            {'Book ID': 'B001', 'Title': 'Python Programming', 'Author': 'John Smith', 'Genre': 'Programming', 'Availability': 'Available'},
            {'Book ID': 'B002', 'Title': 'Data Structures', 'Author': 'Jane Doe', 'Genre': 'Computer Science', 'Availability': 'Available'},
            {'Book ID': 'B003', 'Title': 'Machine Learning', 'Author': 'Alan Turing', 'Genre': 'AI', 'Availability': 'Not Available'}
        ]
    return data

def issue_books():
    try:
        # Get all issued books
        result = db.session.execute(text("""
            SELECT 
                "ISBN",
                "BookID", 
                "Title", 
                "Author", 
                "Category", 
                "Publication", 
                "Issue_Date",
                "Status",
                "UserEmail"
            FROM issued_books
            ORDER BY "Issue_Date" DESC
        """))
        
        # Get column names from the result
        columns = result.keys()
        
        # Convert to list of dictionaries with formatted dates
        issued_books = []
        for row in result:
            # Create dictionary with column names as keys
            book_dict = {}
            for idx, column in enumerate(columns):
                book_dict[column] = row[idx]
            
            # Add overdue status based on issue date (assuming 14 days borrowing period)
            issue_date = book_dict['Issue_Date']
            if issue_date:
                due_date = issue_date + timedelta(days=14)
                book_dict['overdue'] = datetime.now() > due_date
            else:
                book_dict['overdue'] = False
                
            issued_books.append(book_dict)
        
        return issued_books
    except Exception as e:
        print(f"Error fetching issued books: {str(e)}")
        import traceback
        traceback.print_exc()
        return []

def user():
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "lib_users.sql")
    data = load_sql_file(file_path)
    if not data:
        # Provide sample data if SQL file is not found
        data = [
            {'User ID': 'U001', 'User Name': 'John Doe', 'Email ID': 'john@example.com', 'Password': '********', 'Contact Number': '1234567890', 'Date of Birth': '1990-01-01'},
            {'User ID': 'U002', 'User Name': 'Jane Smith', 'Email ID': 'jane@example.com', 'Password': '********', 'Contact Number': '0987654321', 'Date of Birth': '1992-05-15'}
        ]
    return data

# ✅ Define Book Model
class Book(db.Model):
    __tablename__ = "books"

    BookID = db.Column(db.Text, primary_key=True)
    ISBN = db.Column(db.Text, nullable=True)
    Title = db.Column(db.Text, nullable=False)
    Author = db.Column(db.Text, nullable=False)
    Category = db.Column(db.Text, nullable=False)
    Publisher = db.Column(db.Text, nullable=True)
    Date_of_release = db.Column(db.DateTime, nullable=True)
    No_of_Pages = db.Column(db.BigInteger, nullable=True)
    No_of_copies = db.Column(db.BigInteger, nullable=True)
    Availability = db.Column(db.Text, nullable=False)
    Added_at = db.Column(db.DateTime, nullable=True)

# Add this to temp.py after the Book model
class StudentRequestedBooks(db.Model):
    __tablename__ = "student_requested_books"
    
    ISBN = db.Column('ISBN', db.Text)
    BookID = db.Column('BookID', db.Text, db.ForeignKey('books.BookID'), primary_key=True)
    Title = db.Column('Title', db.Text, nullable=False)
    Author = db.Column('Author', db.Text, nullable=False)
    Category = db.Column('Category', db.Text)
    Publication = db.Column('Publication', db.Text)
    Request_Purpose = db.Column('Request_Purpose', db.Text)
    Request_Date = db.Column('Request_Date', db.DateTime, default=datetime.now)
    Status = db.Column('Status', db.Text, default='Pending')
    UserEmail = db.Column('UserEmail', db.Text, primary_key=True)

    def __init__(self, **kwargs):
        super(StudentRequestedBooks, self).__init__(**kwargs)
        if not self.Request_Date:
            self.Request_Date = datetime.now()

def load_books_into_trie():
    books = Book.query.distinct(Book.Title, Book.Author).all()  # ✅ Fetch only unique books
    books_list = [
        {"title": book.Title, "author": book.Author, "year": book.Date_of_release.year if book.Date_of_release else None}
        for book in books
    ]
    return create_books_trie(books_list)

# ✅ Load Trie After App Context is Ready
with app.app_context():
    trie = load_books_into_trie()

def load_excel_file(file_path):
    try:
        # Convert to absolute path if it's not already
        abs_path = os.path.abspath(file_path)
        if not os.path.exists(abs_path):
            print(f"Warning: File not found - {abs_path}")
            # Try to list files in the directory to help debugging
            dir_path = os.path.dirname(abs_path)
            if os.path.exists(dir_path):
                print(f"Files in directory {dir_path}:")
                for f in os.listdir(dir_path):
                    print(f"  - {f}")
            return []
        
        print(f"Loading file: {abs_path}")
        # Explicitly specify engine for xlsx files
        df = pd.read_excel(abs_path, engine='openpyxl')
        
        # Convert date columns to datetime if they exist
        date_columns = ['Date of Birth', 'Borrow Date', 'Due Date', 'Return Date']
        for col in date_columns:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], errors='coerce').dt.strftime('%Y-%m-%d')
        
        records = df.to_dict(orient='records')
        print(f"Successfully loaded {len(records)} records from {os.path.basename(abs_path)}")
        return records
    except Exception as e:
        print(f"Error loading {file_path}: {str(e)}")
        return []

# Update the file path functions to use the correct file names
def due1_books():
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "department_library_transactions.xlsx")
    data = load_excel_file(file_path)
    if not data:
        # Provide sample data if Excel file is not found
        today = datetime.now().strftime('%Y-%m-%d')
        yesterday = (datetime.now() - pd.Timedelta(days=1)).strftime('%Y-%m-%d')
        next_week = (datetime.now() + pd.Timedelta(days=7)).strftime('%Y-%m-%d')
        last_week = (datetime.now() - pd.Timedelta(days=7)).strftime('%Y-%m-%d')
        
        data = [
            {'Transaction ID': 'T001', 'User ID': 'U001', 'Book ID': 'B001', 'Borrow Date': yesterday, 'Due Date': next_week, 'Return Date': None, 'Fines': 0},
            {'Transaction ID': 'T002', 'User ID': 'U002', 'Book ID': 'B002', 'Borrow Date': last_week, 'Due Date': yesterday, 'Return Date': None, 'Fines': 50},
            {'Transaction ID': 'T003', 'User ID': 'U001', 'Book ID': 'B003', 'Borrow Date': last_week, 'Due Date': yesterday, 'Return Date': today, 'Fines': 0}
        ]
    return data

def load_books():
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "department_library_books.xlsx")
    data = load_excel_file(file_path)
    '''
    if not data:
        # Provide sample data if Excel file is not found
        data = [
            {'Book ID': 'B001', 'Title': 'Python Programming', 'Author': 'John Smith', 'Genre': 'Programming', 'Availability': 'Available'},
            {'Book ID': 'B002', 'Title': 'Data Structures', 'Author': 'Jane Doe', 'Genre': 'Computer Science', 'Availability': 'Available'},
            {'Book ID': 'B003', 'Title': 'Machine Learning', 'Author': 'Alan Turing', 'Genre': 'AI', 'Availability': 'Not Available'}
        ]
        '''
    return data

def issue_books():
    try:
        # Get all issued books
        result = db.session.execute(text("""
            SELECT 
                "ISBN",
                "BookID", 
                "Title", 
                "Author", 
                "Category", 
                "Publication", 
                "Issue_Date",
                "Status",
                "UserEmail"
            FROM issued_books
            ORDER BY "Issue_Date" DESC
        """))
        
        # Get column names from the result
        columns = result.keys()
        
        # Convert to list of dictionaries with formatted dates
        issued_books = []
        for row in result:
            # Create dictionary with column names as keys
            book_dict = {}
            for idx, column in enumerate(columns):
                book_dict[column] = row[idx]
            
            # Add overdue status based on issue date (assuming 14 days borrowing period)
            issue_date = book_dict['Issue_Date']
            if issue_date:
                due_date = issue_date + timedelta(days=14)
                book_dict['overdue'] = datetime.now() > due_date
            else:
                book_dict['overdue'] = False
                
            issued_books.append(book_dict)
        
        return issued_books
    except Exception as e:
        print(f"Error fetching issued books: {str(e)}")
        import traceback
        traceback.print_exc()
        return []

def user():
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "department_library_users.xlsx")
    data = load_excel_file(file_path)
    if not data:
        # Provide sample data if Excel file is not found
        data = [
            {'User ID': 'U001', 'User Name': 'John Doe', 'Email ID': 'john@example.com', 'Password': '********', 'Contact Number': '1234567890', 'Date of Birth': '1990-01-01'},
            {'User ID': 'U002', 'User Name': 'Jane Smith', 'Email ID': 'jane@example.com', 'Password': '********', 'Contact Number': '0987654321', 'Date of Birth': '1992-05-15'}
        ]
    return data

PENDING_FILE = 'pending_data.json'

def load_pending():
    if not os.path.exists(PENDING_FILE):
        return []
    with open(PENDING_FILE, 'r') as f:
        return json.load(f)

def save_pending(data):
    with open(PENDING_FILE, 'w') as f:
        json.dump(data, f, indent=2)

# ✅ Homepage Route (Uses index.html)
@app.route('/')
def login():
    return render_template('Untitled-1.html')

@app.route('/forgot-password')
def forgotpassword():
    return render_template('forpass.html')

@app.route('/register-user', methods=['GET', 'POST'])
def register_user():
    if request.method == 'POST':
        try:
            # Convert creationDate to proper timestamp format
            creation_date_str = request.form['creationDate']
            creation_date = datetime.strptime(creation_date_str, "%m/%d/%Y, %I:%M:%S %p")

            user_data = {
                'id': int(request.form['userId']),
                'name': request.form['userName'],
                'email': request.form['email'],
                'password': request.form['password'],
                'contact': request.form['contactNumber'],
                'dob': request.form['dob'],  # Assuming 'YYYY-MM-DD'
                'age': int(request.form['age']),
                'role': request.form['role'],
                'creationDate': creation_date  # Now it's a valid datetime object
            }

            # ✅ Check for duplicate user in 'users' table
            exists_in_users = db.session.execute(
                text('SELECT 1 FROM users WHERE "User ID" = :id'),
                {'id': user_data['id']}
            ).fetchone()

            # ✅ Check for duplicate user in 'users_request' table
            exists_in_users_request = db.session.execute(
                text('SELECT 1 FROM users_request WHERE user_id = :id'),
                {'id': user_data['id']}
            ).fetchone()

            if exists_in_users or exists_in_users_request:
                # Flash error message to be displayed in a pop-up/modal on the frontend
                flash("❌ A user with this ID already exists in the system or is pending approval!", "error")
                return redirect(url_for('register_user'))  # Redirect back to the form

            # ✅ Insert into 'users_request' table if no duplicates
            db.session.execute(text(""" 
                INSERT INTO users_request (
                    user_id, user_name, email, password, contact_number,
                    date_of_birth, age, role, account_creation_date
                ) VALUES (
                    :id, :name, :email, :password, :contact,
                    :dob, :age, :role, :creationDate
                );
            """), user_data)

            db.session.commit()

            # If successful, render a confirmation page or modal
            return render_template('confirmation.html', message="✅ Registration successful!")

        except Exception as e:
            # Rollback transaction in case of error
            db.session.rollback()
            flash(f"❌ Error saving to database: {str(e)}", "error")
            return redirect(url_for('register_user'))

    return render_template('newuserL.html', users=load_pending())


@app.route('/register-user-success')
def request_confirmation():
    return render_template('Untitled-1.html')


@app.route('/admin/pending')
def admin_pending():
    try:
        results = db.session.execute(text("SELECT * FROM users_request")).mappings().all()
        users = [dict(row) for row in results]
        return render_template('newuserA.html', users=users)
    except Exception as e:
        print("❌ Error loading pending users:", str(e))
        return render_template('newuserA.html', users=[], message=f"Error loading pending users: {e}")


# Import the hash_password function
from encrypt import hash_password




@app.route('/home')
def index():
    # Get unique categories for the dropdown
    categories = db.session.query(Book.Category).distinct().all()
    categories = [cat[0] for cat in categories if cat[0]]  # Remove None values
    return render_template('index.html', categories=categories, initial_load=True)

@app.route('/admin')
def admin():
    return render_template('home.html')

import re

@app.route('/delete-book', methods=['GET', 'POST'])
def delete_book():
    if request.method == 'POST':
        book_id = request.form.get('BookID')
        isbn = request.form.get('ISBN')

        if not book_id and not isbn:
            return jsonify({
                'status': 'error',
                'message': 'Please provide either Book ID or ISBN.'
            })

        book = None

        # Try by BookID with format check
        if book_id:
            if not re.match(r'^BK\d{4}$', book_id):
                return jsonify({
                    'status': 'error',
                    'message': 'Book ID must be in the format BK0000.'
                })
            book = Book.query.filter_by(BookID=book_id).first()

        # If not found, try by ISBN
        if not book and isbn:
            book = Book.query.filter_by(ISBN=isbn).first()

        if book:
            db.session.delete(book)
            db.session.commit()
            return jsonify({
                'status': 'success',
                'message': f'Book "{book.Title}" deleted successfully.'
            })
        else:
            return jsonify({
                'status': 'error',
                'message': 'Book not found.'
            })

    return render_template('delete_books.html')

@app.route('/users')
def users():
    user_data = user()
    return render_template("users.html", users=user_data)

@app.route('/issued-books')
def issued_books():
    try:
        # Get user's email and role from session
        user_email = session.get('email')
        user_role = session.get('role', 'user')
        
        print(f"🔍 User email from session: {user_email}")  # Debug log
        print(f"🔍 User role from session: {user_role}")  # Debug log
        
        if not user_email:
            print("❌ No user email found in session")  # Debug log
            return render_template('issued_books.html', error='User not logged in')

        print(f"🔍 Fetching issued books for user: {user_email}")  # Debug log

        # First check if table exists
        table_exists = db.session.execute(text("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = 'issued_books'
            )
        """)).scalar()
        
        print(f"🔍 Table exists: {table_exists}")  # Debug log
        
        if not table_exists:
            print("❌ issued_books table does not exist")  # Debug log
            return render_template('issued_books.html', error='Database table not found')

        # Get all issued books for the current user
        if user_role == 'Admin':
            # Admin can see all issued books
            result = db.session.execute(text("""
                SELECT 
                    ib."bookid" as "bookid", 
                    ib."title" as "title", 
                    ib."author" as "author", 
                    ib."category" as "category", 
                    ib."issue_date" as "issue_date",
                    ib."status" as "status",
                    ib."useremail" as "useremail",
                    ib."renewal_count" as "renewal_count",
                    (ib."last_renewed_date" + INTERVAL '0 days') as "due_date"
                FROM issued_books ib
                ORDER BY ib."issue_date" DESC
            """))
        else:
            # Regular users can only see their own issued books
            result = db.session.execute(text("""
                SELECT 
                    ib."bookid" as "bookid", 
                    ib."title" as "title", 
                    ib."author" as "author", 
                    ib."category" as "category", 
                    ib."issue_date" as "issue_date",
                    ib."status" as "status",
                    ib."useremail" as "useremail",
                    ib."renewal_count" as "renewal_count",
                    (ib."last_renewed_date" + INTERVAL '0 days') as "due_date"
                FROM issued_books ib
                WHERE ib."useremail" = :user_email
                ORDER BY ib."issue_date" DESC
            """), {'user_email': user_email})
        
        # Get column names from the result
        columns = result.keys()
        print(f"📚 Columns in result: {columns}")  # Debug log
        
        # Convert to list of dictionaries with formatted dates
        issued_books = []
        for row in result:
            # Create dictionary with column names as keys
            book_dict = {}
            for idx, column in enumerate(columns):
                value = row[idx]
                # Handle NULL values
                if value is None:
                    value = 'N/A'
                book_dict[column] = value
            
            # Calculate if book is overdue
            due_date = book_dict['due_date']
            if due_date and due_date != 'N/A':
                book_dict['overdue'] = datetime.now() > due_date
                book_dict['days_overdue'] = (datetime.now() - due_date).days if book_dict['overdue'] else 0
            else:
                book_dict['overdue'] = False
                book_dict['days_overdue'] = 0
                
            # Format dates for display
            if book_dict['issue_date'] and book_dict['issue_date'] != 'N/A':
                book_dict['formatted_issue_date'] = book_dict['issue_date'].strftime('%Y-%m-%d')
            else:
                book_dict['formatted_issue_date'] = 'Not set'
                
            if book_dict['due_date'] and book_dict['due_date'] != 'N/A':
                book_dict['formatted_due_date'] = book_dict['due_date'].strftime('%Y-%m-%d')
            else:
                book_dict['formatted_due_date'] = 'Not set'
            
            issued_books.append(book_dict)
        
        print(f"📚 Found {len(issued_books)} books")  # Debug log
        print("📚 Books data:", issued_books)  # Debug log
        
        # If no books found, set a message
        if not issued_books:
            print("ℹ️ No books found for user")  # Debug log
            return render_template('issued_books.html', books=[], message='No issued books found')
        
        return render_template('issued_books.html', books=issued_books, is_admin=(user_role == 'Admin'))
    except Exception as e:
        print(f"❌ Error in issued_books route: {str(e)}")  # Debug log
        return render_template('issued_books.html', error=f'Failed to load issued books: {str(e)}')

from datetime import datetime

@app.route('/admin/overdue-books')
def overdue_books():
    if 'email' not in session or session.get('role') != 'Admin':
        return jsonify({'error': 'Unauthorized'}), 403

    try:
        # Query to fetch overdue books from the overdue_books table
        result = db.session.execute(text(""" 
            SELECT 
                ob."ISBN", 
                ob."BookID", 
                ob."Title", 
                ob."Author", 
                ob."Category", 
                ob."Publisher", 
                ob."IssueDate", 
                ob."Status", 
                ob."UserEmail", 
                ob."RenewalCount", 
                ob."LastRenewedDate", 
                ob."OverdueDate", 
                ob."Fine" 
            FROM overdue_books ob 
        """)).mappings().all()

        # Prepare the books data to pass to the template
        books = []
        for row in result:
            books.append({
                'isbn': row['ISBN'],
                'bookid': row['BookID'],
                'title': row['Title'],
                'author': row['Author'],
                'category': row['Category'],
                'publisher': row['Publisher'],
                'issue_date': row['IssueDate'].strftime('%d-%m-%Y') if row['IssueDate'] else 'N/A',  # Modify format here
                'status': row['Status'],
                'useremail': row['UserEmail'],
                'renewal_count': row['RenewalCount'],
                'last_renewed_date': row['LastRenewedDate'].strftime('%d-%m-%Y') if row['LastRenewedDate'] else 'N/A',  # Modify format here
                'overdue_date': row['OverdueDate'].strftime('%d-%m-%Y') if row['OverdueDate'] else 'N/A',  # Modify format here
                'fine': row['Fine']
            })

        return render_template('overdue_books.html', books=books, is_admin=True)

    except Exception as e:
        return render_template('overdue_books.html', books=[], error=str(e), is_admin=True)


    
@app.route('/due-books')
def due_books():
    try:
        today = datetime.now().date()
        user_email = session.get('email')

        if not user_email:
            return render_template('due_books.html', books=[], error='User not logged in')

        table_exists = db.session.execute(text("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = 'history_books'
            )
        """)).scalar()

        if not table_exists:
            return render_template('due_books.html', books=[], error='History data not found')

        query = text("""
            SELECT 
                recordid,
                bookid,
                title,
                author,
                category,
                issuedate,
                returndate,
                status,
                useremail
            FROM history_books
            ORDER BY returndate DESC NULLS LAST
        """)

        result = db.session.execute(query, {'user_email': user_email})
        books = []

        for row in result:
            data = row._mapping
            print("🔎 Row fetched:", dict(data))  # Add this line to debug

            book = {
                'Record ID': data['recordid'],
                'Book ID': data['bookid'],
                'Title': data['title'],
                'Author': data['author'],
                'Category': data['category'],
                'Issue Date': data['issuedate'].strftime('%Y-%m-%d') if data['issuedate'] else None,
                'Return Date': data['returndate'].strftime('%Y-%m-%d') if data['returndate'] else "Not Returned",
                'Status': data['status'],
                'User Email': data['useremail']
            }
            books.append(book)

        print("✅ Final book list:", books)

        return render_template('due_books.html', books=books, today=today)

    except Exception as e:
        import traceback
        traceback.print_exc()
        return render_template('due_books.html', books=[], error=f'Failed to load book history: {str(e)}')
    
@app.route('/add-book', methods=['GET', 'POST'])
def add_book():
    categories = ['Information Technology', 'Data Science', 'Software Engineering', 'Machine Learning', 'Networking', 
                 'Computer Science', 'Cybersecurity', 'Artificial Intelligence']
    availability_options = ['Available', 'Not Available']

    if request.method == 'POST':
        try:
            # Check if ISBN already exists
            isbn = request.form['ISBN']
            existing_book = Book.query.filter_by(ISBN=isbn).first()
            if existing_book:
                return jsonify({
                    'status': 'error',
                    'message': f"A book with ISBN {isbn} already exists in the database."
                }), 400

            # Generate BookID (format: BK + 4 digits)
            last_book = Book.query.order_by(Book.BookID.desc()).first()
            if last_book:
                book_id_str = ''.join(filter(str.isdigit, last_book.BookID))
                if book_id_str:
                    last_num = int(book_id_str)
                    new_num = last_num + 1
                else:
                    new_num = 1000
            else:
                new_num = 1000

            BookID = f'BK{new_num}'

            new_book = Book(
                BookID=BookID,
                ISBN=isbn,
                Title=request.form['Title'],
                Author=request.form['Author'],
                Category=request.form['Category'],
                Publisher=request.form['Publisher'],
                Date_of_release=datetime.strptime(request.form['Date_of_release'], '%Y-%m-%d'),
                No_of_Pages=request.form['No_of_Pages'],
                No_of_copies=1,
                Availability=request.form['Availability'],
                Added_at=datetime.utcnow()
            )
            
            db.session.add(new_book)
            db.session.commit()

            trie.insert({
                "title": new_book.Title,
                "author": new_book.Author,
                "isbn": new_book.ISBN,
                "category": new_book.Category,
                "publisher": new_book.Publisher,
                "date_of_release": new_book.Date_of_release,
                "no_of_pages": new_book.No_of_Pages,
                "availability": new_book.Availability,
                "added_at": new_book.Added_at
            })
            
            # Set success message in session
            session['success_message'] = f'Book "{new_book.Title}" has been added successfully!'
            
            return jsonify({
                'status': 'success',
                'message': 'Book added successfully',
                'redirect': url_for('allbooks')
            })

        except Exception as e:
            db.session.rollback()
            return jsonify({
                'status': 'error',
                'message': str(e)
            }), 500

    return render_template('add_book.html', 
                         categories=categories,
                         availability_options=availability_options)                         
@app.route('/allbooks')
def allbooks():
    # Get success message from session if it exists
    success_message = session.pop('success_message', None)
    
    # Query all books and convert to list of dictionaries
    books_query = Book.query.all()
    books = []
    for book in books_query:
        books.append({
            'BookID': book.BookID,
            'ISBN': book.ISBN,
            'Title': book.Title,
            'Author': book.Author,
            'Category': book.Category,
            'Publisher': book.Publisher,
            'Date_of_release': book.Date_of_release.strftime('%Y-%m-%d') if book.Date_of_release else None,
            'No_of_Pages': book.No_of_Pages,
            'No_of_copies': book.No_of_copies,
            'Availability': book.Availability,
            'Added_at': book.Added_at.strftime('%Y-%m-%d') if book.Added_at else None
        })
    
    return render_template('books.html', books=books, success_message=success_message)

@app.route('/aboutus')
def about_us():
    return render_template('aboutus.html')

@app.route('/service')
def service():
    return render_template('Service.html')

@app.route('/rules')
def rules():
    return render_template('rules.html')

@app.route('/resources')
def resources():
    return render_template('resources.html')

@app.route('/contactus')
def contactus():
    return render_template('contact_us.html')

@app.route("/books", methods=["GET"])
def get_books():
    try:
        # Get query parameters
        title = request.args.get('title', '').strip()
        category = request.args.get('category', '').strip()
        availability = request.args.get('availability', '').strip().lower()

        # Get user email from session
        user_email = session.get('email')

        # Start with base query
        query = Book.query

        # Apply filters
        if title:
            query = query.filter(Book.Title.ilike(f'%{title}%'))
        if category:
            query = query.filter(Book.Category == category)
        if availability:
            if availability == 'available':
                query = query.filter(Book.Availability.ilike('available'))
            elif availability == 'borrowed':
                query = query.filter(Book.Availability.notilike('available'))

        # Execute query
        books = query.all()
        
        # Convert to list of dictionaries
        books_list = []
        for book in books:
            book_dict = {
                'BookID': book.BookID,
                'ISBN': book.ISBN,
                'title': book.Title,
                'author': book.Author,
                'category': book.Category,
                'availability': book.Availability,
                'date_of_release': book.Date_of_release.isoformat() if book.Date_of_release else None
            }

            # Add borrower info if book is borrowed
            if book.Availability.lower() != 'available':
                issued_book = IssuedBooks.query.filter_by(bookid=book.BookID).first()
                if issued_book:
                    book_dict['borrower_info'] = {
                        'issue_date': issued_book.issue_date.strftime('%Y-%m-%d %H:%M:%S')
                    }

            # ➕ Your additional logic
            is_borrowed_by_user = False
            is_reserved = False

            if user_email:
                borrowed_book = db.session.execute(text("""
                    SELECT 1 FROM issued_books 
                    WHERE bookid = :bookid AND useremail = :user_email
                """), {
                    'bookid': book.BookID,
                    'user_email': user_email
                }).fetchone()
                is_borrowed_by_user = borrowed_book is not None

                reserved_book = StudentRequestedBooks.query.filter_by(
                    BookID=book.BookID,
                    UserEmail=user_email,
                    Status='Pending'
                ).first()
                is_reserved = reserved_book is not None

            if is_borrowed_by_user:
                book_dict['availability_status'] = "Borrowed by You"
            elif is_reserved:
                book_dict['availability_status'] = "Reserved"
            else:
                book_dict['availability_status'] = "Available" if book.Availability.strip().lower() in ["yes", "available", "true", "1"] else "Borrowed"

            books_list.append(book_dict)

        return jsonify(books_list)

    except Exception as e:
        print(f"Error in get_books: {str(e)}")
        return jsonify({"error": "An error occurred while fetching books"}), 500

@app.route("/books/search", methods=["GET"])
def search_book():
    title = request.args.get("title", "").strip()

    if not title:
        return jsonify({"message": "Please provide a book title"}), 400

    # Fetch books with case-insensitive title matching
    books = (
        Book.query.filter(Book.Title.ilike(title))
        .order_by(Book.BookID)  # Ensuring consistent order
        .all()
    )

    # Remove duplicates (ignore case)
    unique_books = {}
    for book in books:
        lower_title = book.Title.lower()
        if lower_title not in unique_books:
            unique_books[lower_title] = book  # Store only one entry per title

    # Convert to JSON format
    result = [{
        "BookID": book.BookID,
        "ISBN": book.ISBN,
        "title": book.Title,
        "author": book.Author,
        "category": book.Category,
        "publisher": book.Publisher,
        "date_of_release": book.Date_of_release.isoformat() if book.Date_of_release else None,
        "no_of_pages": book.No_of_Pages,
        "no_of_copies": book.No_of_Copies,
        "availability": book.Availability,
        "added_at": book.Added_at.isoformat() if book.Added_at else None
    } for book in unique_books.values()]

    if result:
        return jsonify(result)
    
    return jsonify({"message": "Book not found"}), 404


# ✅ Book Suggestion Endpoint Using Trie (Returns JSON)
@app.route('/suggest')
def suggest():
    prefix = request.args.get('prefix', '').lower()
    if not prefix:
        return jsonify([])
    suggestions = trie.search(prefix)
    return jsonify(suggestions)

# ✅ View Cart (Uses cart.html)
@app.route('/cart')
def cart():
    try:
        # Get cart items from session
        cart_items = session.get('cart', [])
        
        # Get user's email from session
        user_email = session.get('email')
        print(f"Debug - User email from session: {user_email}")
        
        if not user_email:
            print("Debug - No user email found in session")
            return render_template('cart.html', cart_items=[], cart_count=0, error='User not logged in')
        
        # First check if the issued_books table exists
        table_exists = db.session.execute(text("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = 'issued_books'
            )
        """)).scalar()
        
        print(f"Debug - issued_books table exists: {table_exists}")
        
        if not table_exists:
            print("Debug - issued_books table does not exist")
            return render_template('cart.html', cart_items=cart_items, cart_count=len(cart_items), error='Database table not found')
        
        # Get issued books for the current user
        issued_books = []
        try:
            # First, let's check what books exist for this user
            debug_query = db.session.execute(text("""
                SELECT bookid, title, status, useremail 
                FROM issued_books 
                WHERE useremail = :user_email
            """), {'user_email': user_email})
            
            print(f"Debug - Found {debug_query.rowcount} books for user {user_email}")
            for row in debug_query:
                print(f"Debug - Book: {row[0]}, Status: {row[2]}")
            
            # Now get the books with the correct status
            result = db.session.execute(text("""
                SELECT 
                    ib.bookid,
                    ib.title,
                    ib.author,
                    ib.issue_date,
                    ib.last_renewed_date + INTERVAL '0 days' as due_date,
                    ib.status
                FROM issued_books ib
                WHERE ib.useremail = :user_email
                AND ib.status IN ('On Time', 'Return Requested')
                ORDER BY ib.issue_date DESC
            """), {'user_email': user_email})
            
            print("Debug - SQL query executed successfully")
            
            for row in result:
                book = {
                    'Book ID': row[0],
                    'Title': row[1],
                    'Author': row[2],
                    'Issue Date': row[3].strftime('%Y-%m-%d') if row[3] else None,
                    'Due Date': row[4].strftime('%Y-%m-%d') if row[4] else None,
                    'Status': row[5] if row[5] else 'On Time'
                }
                issued_books.append(book)
                print(f"Debug - Added book: {book}")
            
            print(f"Debug - Found {len(issued_books)} issued books")
            
        except Exception as e:
            print(f"Debug - Error fetching issued books: {str(e)}")
            issued_books = []
        
        return render_template(
            'cart.html', 
            cart_items=cart_items, 
            cart_count=len(cart_items),
            issued_books=issued_books
        )
    except Exception as e:
        print(f"Debug - Error in cart route: {str(e)}")
        return render_template('cart.html', cart_items=[], cart_count=len(cart_items), error=str(e))

@app.route('/cart/add', methods=['POST'])
def add_to_cart():
    try:
        book = request.get_json()
        print("📥 Received book data:", book)  # Debugging

        if not book:
            return jsonify({"error": "No book data received"}), 400

        # Get user's email from session
        user_email = session.get('email')
        if not user_email:
            return jsonify({"error": "User not logged in"}), 401

        # Check if book is already issued to this user
        issued_book = db.session.execute(text("""
            SELECT 1 FROM issued_books 
            WHERE bookid = :bookid AND useremail = :user_email
        """), {
            'bookid': book.get('id'),
            'user_email': user_email
        }).fetchone()

        if issued_book:
            return jsonify({
                "error": "You have already borrowed this book. Please return it before borrowing again."
            }), 400

        # Ensure session['cart'] is a list
        if 'cart' not in session:
            session['cart'] = []

        cart_items = session['cart']

        # Check if book already exists in cart
        if not any(item.get('title') == book.get('title') for item in cart_items):
            # Get additional book details from database
            db_book = Book.query.filter_by(BookID=book.get('id')).first()
            
            # Extract year from date_of_release
            year = None
            if db_book and db_book.Date_of_release:
                year = db_book.Date_of_release.year
            
            # Ensure all required fields are present
            cart_book = {
                'id': book.get('id'),
                'title': book.get('title'),
                'author': db_book.Author if db_book else book.get('author'),
                'year': year if year else 'N/A'
            }
            cart_items.append(cart_book)
            session['cart'] = cart_items
            return jsonify({
                "message": "Book added to cart",
                "cart_count": len(cart_items)
            })
        
        return jsonify({
            "message": "Book already in cart",
            "cart_count": len(cart_items)
        })
    except Exception as e:
        print(f"Error in add_to_cart: {str(e)}")
        return jsonify({"error": str(e)}), 500

# ✅ Get Cart Items
@app.route('/cart', methods=['GET'])
def get_cart():
    cart_items = session.get('cart', [])
    return jsonify({"cart": cart_items, "cart_count": len(cart_items)})

# ✅ Remove a Book from Cart (Returns JSON)
@app.route('/cart/remove', methods=['POST'])
def remove_from_cart():
    book = request.get_json()
    if not book:
        return jsonify({"error": "No book data provided"}), 400

    cart_items = session.get('cart', [])
    cart_items = [item for item in cart_items if item['title'] != book['title']]
    session['cart'] = cart_items

    # ✅ Return updated cart count
    return jsonify({
        "message": "Book removed from cart",
        "cart_count": len(cart_items)
    })


@app.route('/cart/checkout', methods=['POST'])
def checkout():
    try:
        # Check if user is logged in
        if not session.get('logged_in'):
            return jsonify({
                "error": "User not logged in",
                "redirect": "/"
            }), 401

        cart_items = session.get('cart', [])
        if not cart_items:
            return jsonify({"error": "Cart is empty"}), 400

        # Get user email from session
        user_email = session.get('email')
        if not user_email:
            return jsonify({
                "error": "User session error",
                "redirect": "/"
            }), 401

        successful_requests = []
        errors = []
        current_time = datetime.now()

        for item in cart_items:
            try:
                title = item.get('title', '').strip()
                if not title:
                    continue

                book = Book.query.filter(Book.Title.ilike(title)).first()
                if not book:
                    errors.append(f"Book not found: {title}")
                    continue

                # Insert using raw SQL with explicit timestamp
                result = db.session.execute(text("""
                    INSERT INTO student_requested_books 
                    ("ISBN", "BookID", "Title", "Author", "Category", 
                     "Publication", "Request_Purpose", "Status", "Request_Date", "UserEmail")
                    VALUES (:isbn, :bookid, :title, :author, :category, 
                           :publication, :purpose, :status, :request_date, :user_email)
                """), {
                    'isbn': book.ISBN,
                    'bookid': book.BookID,
                    'title': book.Title,
                    'author': book.Author,
                    'category': book.Category,
                    'publication': book.Publisher,
                    'purpose': "Borrowing",
                    'status': 'Pending',
                    'request_date': current_time,
                    'user_email': user_email
                })
                # ✅ Corrected update query with consistent casing
                if book.Availability.strip().lower() == 'available':
                    print(f"Reserving book: {book.BookID}")  # Debug log
                    db.session.execute(text("""
                        UPDATE books
                        SET "Availability" = 'Reserved'
                        WHERE "BookID" = :BookID
                    """), {'BookID': book.BookID})

                successful_requests.append(title)
            except Exception as item_error:
                if "duplicate key" in str(item_error).lower():
                    errors.append(f"This book is already reserved by you. You cannot borrow it again: {title}")
                else:
                    print(f"Error processing item: {str(item_error)}")
                    errors.append(f"Error processing '{title}': {str(item_error)}")
                continue

        if successful_requests:
            try:
                db.session.commit()
                session['cart'] = []
                return jsonify({
                    "message": "Checkout successful. Your books have been requested.",
                    "successful_requests": successful_requests,
                    "errors": errors if errors else None
                })
            except Exception as commit_error:
                print(f"Commit error: {str(commit_error)}")
                db.session.rollback()
                return jsonify({
                    "error": "Failed to save requests",
                    "details": str(commit_error)
                }), 500
        else:
            return jsonify({
                "error": "No books were processed",
                "details": errors
            }), 400

    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        db.session.rollback()
        return jsonify({
            "error": "Failed to process checkout",
            "details": str(e)
        }), 500

            
verification_codes = {}

def generate_verification_code():
    """Generate a random 6-digit verification code"""
    return ''.join(random.choices(string.digits, k=6))

def send_verification_email(recipient_email, verification_code):
    """Send verification code to the user's email"""
    # Email configuration
    sender_email = "itlibrary377@gmail.com"  # TODO: Replace with your Gmail address
    password = "vgbg hynz qjgk qxoo"  # TODO: Replace with your app password (not your regular password)
    
    # IMPORTANT: To use Gmail SMTP, you need to:
    # 1. Turn on 2-Step Verification in your Google Account security settings
    # 2. Create an "App Password" specifically for this application
    # 3. Use that App Password here instead of your regular Gmail password
    # See: https://support.google.com/accounts/answer/185833
    
    # Create message
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = recipient_email
    message["Subject"] = "Password Reset Verification Code"
    
    # Email body
    body = f"""
    Hello,
    
    You have requested to reset your password. Use the following verification code to complete the process:
    
    {verification_code}
    
    If you did not request this, please ignore this email.
    
    Thank you,
    Department Library System
    """
    
    message.attach(MIMEText(body, "plain"))
    
    try:
        # Create SMTP session
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()  # Secure the connection
        
        # Login to email server
        server.login(sender_email, password)
        
        # Send email
        text = message.as_string()
        server.sendmail(sender_email, recipient_email, text)
        
        # Close connection
        server.quit()
        
        return True
    except Exception as e:
        logger.error(f"Error sending email: {str(e)}")
        return False

@app.route('/verify-login', methods=['POST'])
def verify_login():
    try:
        login_data = request.get_json()
        
        # Debug print the received data
        logger.debug(f"Received login data: {login_data}")
        
        email = login_data.get('email', '').strip()
        password = login_data.get('password', '').strip()
        
        if not email or not password:
            return jsonify({"detail": "Email and password are required"}), 400

        # Query the hashusers table
        result = db.session.execute(text("""
            SELECT user_id, email, password, role 
            FROM hashusers 
            WHERE email = :email
        """), {'email': email})
        
        user = result.fetchone()
        
        if user:
            # Verify the password using bcrypt
            stored_hash = user.password
            is_valid = verify_password(stored_hash, password)
            
            if is_valid:
                # Store user information in session
                session['email'] = email
                session['logged_in'] = True
                session['role'] = user.role or 'user'
                
                logger.info(f"Successful login attempt for email: {email} with role: {session['role']}")
                return jsonify({
                    "status": "success", 
                    "message": "Login successful",
                    "role": session['role']
                })
        
        logger.warning(f"Failed login attempt for email: {email}")
        return jsonify({"detail": "Invalid credentials"}), 401
            
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        logger.error(f"Error type: {type(e)}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"detail": f"Server error: {str(e)}"}), 500


@app.route('/send-verification-code', methods=['POST'])
def send_verification_code():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"detail": "No data provided"}), 400
            
        email = data.get('email', '').strip()
        
        if not email:
            return jsonify({"detail": "Email is required"}), 400
        
        # Check if email exists in the users table
        user = db.session.execute(text("""
            SELECT "Email ID" FROM users WHERE "Email ID" = :email
        """), {'email': email}).fetchone()
        
        if not user:
            logger.warning(f"Email not found for verification: {email}")
            return jsonify({"detail": "Email not found"}), 404
        
        # Generate verification code
        verification_code = generate_verification_code()
        
        # Store verification code
        verification_codes[email] = verification_code
        
        # Send verification email
        email_sent = send_verification_email(email, verification_code)
        
        if email_sent:
            logger.info(f"Verification code sent to: {email}")
            return jsonify({"status": "success", "message": "Verification code sent"})
        else:
            logger.error(f"Failed to send verification email to: {email}")
            return jsonify({"detail": "Failed to send verification email"}), 500
            
    except Exception as e:
        logger.error(f"Unexpected error in send_verification_code: {str(e)}")
        return jsonify({"detail": f"Server error: {str(e)}"}), 500

@app.route('/verify-code', methods=['POST'])
def verify_code():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"detail": "No data provided"}), 400
            
        email = data.get('email', '').strip()
        code = data.get('verification_code', '').strip()
        
        if not email or not code:
            return jsonify({"detail": "Email and verification code are required"}), 400
        
        # Check if the verification code matches
        stored_code = verification_codes.get(email)
        
        if not stored_code or stored_code != code:
            logger.warning(f"Invalid verification code for: {email}")
            return jsonify({"detail": "Invalid verification code"}), 400
        
        # Code is valid
        logger.info(f"Verification code validated for: {email}")
        return jsonify({"status": "success", "message": "Verification successful"})
        
    except Exception as e:
        logger.error(f"Unexpected error in verify_code: {str(e)}")
        return jsonify({"detail": f"Server error: {str(e)}"}), 500

@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    if request.method == 'GET':
        return render_template('forpass.html')
        
    try:
        reset_data = request.get_json()
        
        # Debug print the received data
        logger.debug(f"Received password reset data: {reset_data}")
        
        # Get email, new password, and verification code from request
        email = reset_data.get('email', '').strip()
        new_password = reset_data.get('new_password', '').strip()
        verification_code = reset_data.get('verification_code', '').strip()
        
        if not email or not new_password or not verification_code:
            return jsonify({"detail": "Email, new password, and verification code are required"}), 400
        
        # Verify the code
        stored_code = verification_codes.get(email)
        if not stored_code or stored_code != verification_code:
            logger.warning(f"Invalid verification code for password reset: {email}")
            return jsonify({"detail": "Invalid verification code"}), 400
        
        try:
            # Start a database transaction
            db.session.begin()
            
            # Hash the new password
            hashed_password = hash_password(new_password)
            
            # Update password in hashusers table
            result = db.session.execute(text("""
                UPDATE hashusers 
                SET password = :new_password 
                WHERE email = :email
            """), {
                'new_password': hashed_password,
                'email': email
            })
            
            # Update password in users table
            result2 = db.session.execute(text("""
                UPDATE users 
                SET "Password" = :new_password 
                WHERE "Email ID" = :email
            """), {
                'new_password': new_password,  # Store plain password in users table as per existing schema
                'email': email
            })
            
            # Commit the transaction
            db.session.commit()
            
            # Remove the used verification code
            if email in verification_codes:
                del verification_codes[email]
            
            logger.info(f"Password successfully reset for email: {email}")
            return jsonify({
                "status": "success", 
                "message": "Password reset successful"
            })
            
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Database error during password reset: {str(e)}")
            return jsonify({"detail": f"Database error: {str(e)}"}), 500
            
    except Exception as e:
        logger.error(f"Unexpected error in password reset: {str(e)}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"detail": f"Server error: {str(e)}"}), 500
        
def send_email(to_email, subject, body):
    msg = EmailMessage()
    msg['From'] = "itlibrary377@gmail.com"
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.set_content(body)

    with smtplib.SMTP('smtp.gmail.com', 587) as server:
        server.starttls()
        server.login("itlibrary377@gmail.com", "vgbg hynz qjgk qxoo")
        server.send_message(msg)

@app.route('/admin/process-return', methods=['POST'])
def process_return():
    try:
        # ✅ Admin check
        if session.get('role') != 'Admin':
            return jsonify({'error': 'Unauthorized access. Admin privileges required.'}), 403

        data = request.get_json()
        bookid = data.get('bookid')
        user_email = data.get('user_email')

        if not bookid or not user_email:
            return jsonify({'error': 'Missing bookid or user_email'}), 400

        # ✅ Begin DB transaction
        db.session.begin()

        try:
            # ✅ Fetch issued book details
            issued_book = db.session.execute(text("""
                SELECT bookid, title, author, category, issue_date, status, useremail 
                FROM issued_books 
                WHERE bookid = :bookid AND useremail = :user_email AND status IN ('On Time', 'Return Requested')
            """), {
                'bookid': bookid,
                'user_email': user_email
            }).mappings().fetchone()

            if not issued_book:
                return jsonify({'error': 'Issued book not found or invalid return status'}), 404

            # ✅ Insert into history_books
            db.session.execute(text("""
                INSERT INTO history_books 
                (bookid, title, author, category, issuedate, returndate, status, useremail)
                VALUES 
                (:bookid, :title, :author, :category, :issuedate, :returndate, :status, :useremail)
            """), {
                'bookid': issued_book['bookid'],
                'title': issued_book['title'],
                'author': issued_book['author'],
                'category': issued_book['category'],
                'issuedate': issued_book['issue_date'],
                'returndate': datetime.now(),
                'status': 'Returned',
                'useremail': issued_book['useremail']
            })

            # ✅ Delete from issued_books
            db.session.execute(text("""
                DELETE FROM issued_books 
                WHERE bookid = :bookid AND useremail = :user_email
            """), {
                'bookid': bookid,
                'user_email': user_email
            })

            # ✅ Update availability in books table
            db.session.execute(text("""
                UPDATE books 
                SET "Availability" = 'Available' 
                WHERE "BookID" = :bookid
            """), {'bookid': bookid})

            # ✅ Commit DB transaction
            db.session.commit()

            # ✅ Send email
            subject = 'Book Return Confirmation'
            body = f'The book "{issued_book["title"]}" has been successfully returned.'
            send_email(issued_book['useremail'], subject, body)

            return jsonify({'message': 'Book returned successfully and confirmation email sent'})

        except Exception as e:
            db.session.rollback()
            print(f"Error processing book return: {str(e)}")
            return jsonify({'error': f'Failed to process book return: {str(e)}'}), 500

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
@app.route('/admin/send-reminder', methods=['POST'])
def send_reminder():
    try:
        data = request.get_json()
        if not data or 'user_email' not in data:
            return jsonify({'error': 'Missing user_email'}), 400

        user_email = data['user_email']

        # Fetch book details for issued books
        result = db.session.execute(
            text("""
                SELECT title, last_renewed_date, status
                FROM issued_books
                WHERE useremail = :user_email AND status IN ('On Time', 'Overdue')
            """),
            {'user_email': user_email}
        ).mappings().fetchall()  # ✅ Convert result to list of dicts

        if result:
            # Send a single reminder email listing all due books
            books_list = "\n".join([
                f"- {row['title']} (Due: {row['last_renewed_date'].strftime('%Y-%m-%d') if row['last_renewed_date'] else 'N/A'}, Status: {row['status']})"
                for row in result
            ])
            subject = 'Book Due Date Reminder'
            body = f"Please return the following books by their due dates:\n{books_list}"
            send_email(user_email, subject, body)

            return jsonify({'message': 'Reminder sent successfully'})
        else:
            return jsonify({'error': 'No issued books found for this user'}), 404

    except Exception as e:
        print(f"Error in send_reminder: {str(e)}")
        return jsonify({'error': f'Internal server error: {str(e)}'}), 500

# Your existing issued_books function and other routes go here
# ✅ Notification Email for Book Request Status
def send_request_status_email(to_email, book_title, status):
    subject = f'Your Book Request has been {status}'
    body = f'''Hello,

Your request for the book "{book_title}" has been {status.lower()} by the admin.

Thank you,
IT Library'''
    send_email(to_email, subject, body)



@app.route('/renew-book', methods=['POST'])
def renew_book():
    try:
        # Check if user is logged in
        user_email = session.get('email')
        if not user_email:
            return jsonify({'error': 'User not logged in'}), 401

        # Get book details from request
        data = request.get_json()
        bookid = data.get('bookid')
        title = data.get('title')

        if not bookid or not title:
            return jsonify({'error': 'Missing book details'}), 400

        # Start a transaction
        db.session.begin()

        # First check current renewal count and due date
        current_book = db.session.execute(text("""
            SELECT issue_date, renewal_count 
            FROM issued_books 
            WHERE bookid = :bookid AND useremail = :user_email
        """), {
            'bookid': bookid,
            'user_email': user_email
        }).mappings().fetchone()

        print("Fetched DB row:", current_book)

        if not current_book:
            return jsonify({'error': 'Book not found in your issued books'}), 404

        current_renewal_count = current_book['renewal_count'] if current_book['renewal_count'] is not None else 0
        print("Renewal Count From DB:", current_renewal_count)
        if current_renewal_count >= 10:
            return jsonify({'error': 'Maximum renewal limit (10 times) reached for this book'}), 400

        # Calculate new due date (14 days from now)
        new_due_date = datetime.now() + timedelta(days=14)

        # Update the issue date and renewal count in issued_books table
        db.session.execute(text("""
            UPDATE issued_books 
            SET last_renewed_date = :new_due_date,
                renewal_count = :new_renewal_count,
                status = 'On Time'
            WHERE bookid = :bookid AND useremail = :user_email
        """), {
            'bookid': bookid,
            'user_email': user_email,
            'new_due_date': new_due_date,
            'new_renewal_count': current_renewal_count + 1
        })

        db.session.commit()
        return jsonify({
            'message': 'Book renewed successfully',
            'new_due_date': new_due_date.strftime('%Y-%m-%d'),
            'renewal_count': current_renewal_count + 1
        })

    except Exception as e:
        db.session.rollback()
        print(f"Error renewing book: {str(e)}")
        return jsonify({'error': f'Failed to renew book: {str(e)}'}), 500

@app.route('/return-book', methods=['POST'])
def return_book():
    try:
        if 'email' not in session:
            return jsonify({'error': 'Please login first'}), 401
            
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
            
        bookid = data.get('bookid')
        user_email = session['email']
        
        if not bookid:
            return jsonify({'error': 'Book ID is required'}), 400
            
        # Start a transaction
        db.session.begin()
        
        try:
            # Update the status to 'Return Requested'
            db.session.execute(text("""
                UPDATE issued_books 
                SET status = 'Return Requested'
                WHERE bookid = :bookid AND useremail = :user_email
            """), {'bookid': bookid, 'user_email': user_email})
            
            db.session.commit()
            return jsonify({'message': 'Book return requested successfully!'})
            
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Add this route to test database connection
@app.route('/test-db')
def test_db():
    try:
        # Try to query any book
        book = Book.query.first()
        return jsonify({
            "status": "success",
            "message": "Database connection working",
            "sample_book": {
                "title": book.Title,
                "copies": book.No_of_copies
            }
        })
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route('/requested-books')
def requested_books():
    try:
        # Get user's email from session
        user_email = session.get('email')
        if not user_email:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'error': 'User not logged in'}), 401
            return render_template('requested_books.html', error='User not logged in')

        # Check if user is admin
        is_admin = session.get('role') == 'Admin'

        # Get requested books based on user role
        if is_admin:
            # Admin can see all requested books
            result = db.session.execute(text("""
                SELECT 
                    srb."ISBN",
                    srb."BookID" as "BookID", 
                    srb."Title" as "Title", 
                    srb."Author" as "Author", 
                    srb."Category" as "Category", 
                    srb."Publication" as "Publication", 
                    srb."Request_Purpose" as "Request_Purpose",
                    srb."Request_Date" as "Request_Date",
                    srb."Status" as "Status",
                    srb."UserEmail" as "UserEmail"
                FROM student_requested_books srb
                ORDER BY srb."Request_Date" DESC
            """))
        else:
            # Regular users can only see their own requested books
            result = db.session.execute(text("""
                SELECT 
                    srb."ISBN",
                    srb."BookID" as "BookID", 
                    srb."Title" as "Title", 
                    srb."Author" as "Author", 
                    srb."Category" as "Category", 
                    srb."Publication" as "Publication", 
                    srb."Request_Purpose" as "Request_Purpose",
                    srb."Request_Date" as "Request_Date",
                    srb."Status" as "Status",
                    srb."UserEmail" as "UserEmail"
                FROM student_requested_books srb
                WHERE srb."UserEmail" = :user_email
                ORDER BY srb."Request_Date" DESC
            """), {'user_email': user_email})
        
        # Get column names from the result
        columns = result.keys()
        
        # Convert to list of dictionaries with formatted dates
        requested_books = []
        for row in result:
            # Create dictionary with column names as keys
            book_dict = {}
            for idx, column in enumerate(columns):
                value = row[idx]
                # Handle NULL values
                if value is None:
                    value = 'N/A'
                book_dict[column] = value
            
            # Format the date
            if book_dict['Request_Date'] and book_dict['Request_Date'] != 'N/A':
                book_dict['formatted_date'] = book_dict['Request_Date'].strftime('%Y-%m-%d %H:%M')
            else:
                book_dict['formatted_date'] = 'Not set'
            
            requested_books.append(book_dict)
        
        # Check if the request is from the cart page
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify(requested_books)
        else:
            return render_template('requested_books.html', books=requested_books, is_admin=is_admin)
    except Exception as e:
        print(f"Error fetching requested books: {str(e)}")
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'error': f'Failed to load requested books: {str(e)}'}), 500
        else:
            return render_template('requested_books.html', error=f'Failed to load requested books: {str(e)}')

def get_db_connection():
    try:
        conn = db.engine.connect()
        return conn
    except Exception as e:
        print(f"Error connecting to database: {str(e)}")
        raise

@app.route('/admin/approve-request', methods=['POST'])
def approve_request():
    try:
        # Check session
        if 'email' not in session:
            return jsonify({'error': 'Session expired. Please login again.'}), 401
        if session.get('role') != 'Admin':
            return jsonify({'error': 'Unauthorized access. Admin privileges required.'}), 403

        # Parse request data
        data = request.get_json()
        bookid = data.get('bookid')
        user_email = data.get('user_email')
        title = data.get('title')

        if not all([bookid, user_email, title]):
            return jsonify({'error': 'Missing required fields', 
                            'received': {'bookid': bookid, 'user_email': user_email, 'title': title}}), 400

        db.session.begin()

        try:
            # Update book availability
            db.session.execute(text("""
                UPDATE "books" 
                SET "Availability" = 'Borrowed' 
                WHERE "BookID" = :bookid
            """), {'bookid': bookid})

            # Insert into issued_books
            db.session.execute(text("""
                INSERT INTO "issued_books" 
                ("isbn", "bookid", "title", "author", "category", "publication", "issue_date", "status", "useremail") 
                VALUES (
                    (SELECT "ISBN" FROM "books" WHERE "BookID" = :bookid),
                    :bookid, 
                    :title, 
                    (SELECT "Author" FROM "books" WHERE "BookID" = :bookid),
                    (SELECT "Category" FROM "books" WHERE "BookID" = :bookid),
                    (SELECT "Publisher" FROM "books" WHERE "BookID" = :bookid),
                    :issue_date,
                    'On Time',
                    :user_email
                )
            """), {
                'bookid': bookid,
                'title': title,
                'user_email': user_email,
                'issue_date': datetime.now()
            })

            # Delete from request table
            db.session.execute(text("""
                DELETE FROM "student_requested_books" 
                WHERE "BookID" = :bookid AND "UserEmail" = :user_email
            """), {'bookid': bookid, 'user_email': user_email})

            # Remove from cart
            if 'cart' in session:
                session['cart'] = [item for item in session['cart'] if item.get('id') != bookid]

            db.session.commit()

            # ✅ Send approval email
            send_request_status_email(user_email, title, 'Approved')

            return jsonify({'message': 'Request approved and email sent successfully'})

        except Exception as e:
            db.session.rollback()
            return jsonify({'error': f'Database error: {str(e)}'}), 500

    except Exception as e:
        return jsonify({'error': f'Server error: {str(e)}'}), 500

@app.route('/admin/reject-request', methods=['POST'])
def reject_request():
    try:
        if 'email' not in session:
            return jsonify({'error': 'Session expired. Please login again.'}), 401
        if session.get('role') != 'Admin':
            return jsonify({'error': 'Unauthorized access. Admin privileges required.'}), 403

        data = request.get_json()
        bookid = data.get('bookid')
        user_email = data.get('user_email')
        title = data.get('title')

        if not all([bookid, user_email, title]):
            return jsonify({'error': 'Missing required fields',
                            'received': {'bookid': bookid, 'user_email': user_email, 'title': title}}), 400

        db.session.begin()

        try:
            db.session.execute(text("""
                UPDATE "books" 
                SET "Availability" = 'Available' 
                WHERE "BookID" = :bookid
            """), {'bookid': bookid})

            db.session.execute(text("""
                DELETE FROM "student_requested_books" 
                WHERE "BookID" = :bookid AND "UserEmail" = :user_email
            """), {'bookid': bookid, 'user_email': user_email})

            if 'cart' in session:
                session['cart'] = [item for item in session['cart'] if item.get('id') != bookid]

            db.session.commit()

            # ✔ Send rejection email
            try:
                send_request_status_email(user_email, title, 'Rejected')
            except Exception as email_error:
                print(f"⚠ Email sending failed: {str(email_error)}")

            return jsonify({'message': 'Request rejected and email sent successfully'})

        except Exception as db_error:
            db.session.rollback()
            return jsonify({'error': f'Database error: {str(db_error)}'}), 500

    except Exception as e:
        return jsonify({'error': f'Server error: {str(e)}'}), 500

def init_db():
    try:
        # Create all tables
        db.create_all()
        print("✅ Database tables created successfully")
        
        # Check if books table is empty
        if not Book.query.first():
            # Load books from Excel file
            load_excel_file('books.xlsx')
            print("✅ Books loaded successfully")
        
        return True
    except Exception as e:
        print(f"❌ Error initializing database: {str(e)}")
        return False

# Initialize the database when the application starts
with app.app_context():
    init_db()

class IssuedBooks(db.Model):
    __tablename__ = "issued_books"

    bookid = db.Column(db.Text, primary_key=True)
    isbn = db.Column(db.Text)
    title = db.Column(db.Text, nullable=False)
    author = db.Column(db.Text, nullable=False)
    category = db.Column(db.Text)
    publication = db.Column(db.Text)
    issue_date = db.Column(db.DateTime, default=datetime.now)
    status = db.Column(db.Text, default='On Time', 
                      server_default='On Time',
                      info={'check_constraint': 'status IN (\'On Time\', \'Overdue\', \'Return Requested\', \'Returned\')'})
    useremail = db.Column(db.Text, primary_key=True)
    renewal_count = db.Column(db.Integer, default=0, server_default='0')
    last_renewed_date = db.Column(db.Date)

    _table_args_ = (
        db.CheckConstraint("status IN ('On Time', 'Overdue', 'Return Requested')", name='issued_books_status_check'),
    )

@app.route('/admin/approve-user/<string:user_id>', methods=['POST'])
def approve_user(user_id):
    try:
        # Start a transaction
        db.session.begin()
        
        # Fetch user data from users_request table and use .mappings() to get a dictionary
        user_result = db.session.execute(text(""" 
            SELECT * FROM users_request 
            WHERE user_id = :user_id
        """), {'user_id': user_id}).mappings().fetchone()

        if not user_result:
            return jsonify({'error': 'User request not found'}), 404

        # Extract user details
        uid = user_result['user_id']
        uname = user_result['user_name']
        email = user_result['email']
        raw_pwd = user_result['password']  # Original plaintext password
        contact = user_result['contact_number']
        dob = user_result['date_of_birth']
        age = user_result['age']
        role = user_result['role']
        created = user_result['account_creation_date']

        # Hash the password for hashusers table
        hashed_pwd = hash_password(raw_pwd)

        # Prepare data for users and hashusers tables
        user_data = {
            'uid': uid,
            'uname': uname,
            'email': email,
            'pwd': raw_pwd,  # Keep plaintext password in users table
            'contact': contact,
            'dob': dob,
            'age': age,
            'role': role,
            'created': created
        }

        hashed_user_data = {
            **user_data,
            'pwd': hashed_pwd  # Use hashed password for hashusers table
        }

        # Check for duplicate in users and hashusers tables
        exists_in_users = db.session.execute(
            text('SELECT 1 FROM users WHERE "User ID" = :uid'),
            {'uid': str(uid)}
        ).fetchone()

        exists_in_hashusers = db.session.execute(
            text("SELECT 1 FROM hashusers WHERE user_id = :uid"),
            {'uid': str(uid)}  # Ensure UID is passed as string
        ).fetchone()

        if exists_in_users or exists_in_hashusers:
            flash("❌ A user with this ID already exists!", "error")
            return redirect(url_for('admin_pending'))

        # Insert into users table (plaintext password if needed)
        db.session.execute(
            text(""" 
                INSERT INTO users (
                    "User ID", "User Name", "Email ID", "Password", "Contact Number", 
                    "Date of Birth", "Age", "Role", "Account Creation Date"
                ) VALUES (
                    :uid, :uname, :email, :pwd, :contact, :dob, :age, :role, :created
                )
            """), user_data
        )

        # Insert into hashusers table (hashed password)
        db.session.execute(
            text(""" 
                INSERT INTO hashusers (
                    user_id, user_name, email, password, contact_number, 
                    date_of_birth, age, role, account_creation_date
                ) VALUES (
                    :uid, :uname, :email, :pwd, :contact, :dob, :age, :role, :created
                )
            """), hashed_user_data
        )

        # Delete from users_request table
        db.session.execute(
            text("DELETE FROM users_request WHERE user_id = :user_id"),
            {'user_id': user_id}
        )

        # Send approval email
        sender_email = "itlibrary377@gmail.com"
        password = "vgbg hynz qjgk qxoo"  # Your app password

        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = user_result['email']
        message["Subject"] = "SSN IT Library - Account Approved"

        body = f"""
        Dear {user_result['user_name']},
        
        Your account request for the SSN IT Department Library has been approved!
        
        You can now log in to the library system using:
        Email: {user_result['email']}
        Password: (the password you provided during registration)
        
        Please change your password after your first login for security purposes.
        
        Best regards,
        SSN IT Department Library Team
        """
        
        message.attach(MIMEText(body, "plain"))
        
        try:
            # Create SMTP session and send email
            server = smtplib.SMTP("smtp.gmail.com", 587)
            server.starttls()
            server.login(sender_email, password)
            server.sendmail(sender_email, user_result['email'], message.as_string())
            server.quit()
        except Exception as e:
            print(f"Error sending email: {str(e)}")
            # Continue with the approval process even if email fails

        # Commit the transaction
        db.session.commit()
        
        return redirect(url_for('admin_pending'))
        
    except Exception as e:
        db.session.rollback()
        print(f"Error approving user: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/admin/reject/<string:user_id>', methods=['POST'])
def reject_user(user_id):
    try:
        # Start a transaction
        db.session.begin()

        # Get user details from users_request table
        user_result = db.session.execute(text("""
            SELECT * FROM users_request 
            WHERE user_id = :user_id
        """), {'user_id': user_id}).fetchone()

        if not user_result:
            return jsonify({'error': 'User request not found'}), 404

        # Delete from users_request table
        db.session.execute(text("""
            DELETE FROM users_request 
            WHERE user_id = :user_id
        """), {'user_id': user_id})

        # Send rejection email
        sender_email = "itlibrary377@gmail.com"
        password = "vgbg hynz qjgk qxoo"  # Your app password
        
        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = user_result.email
        message["Subject"] = "SSN IT Library - Account Request Rejected"
        
        body = f"""
        Dear {user_result.user_name},
        
        We regret to inform you that your account request for the SSN IT Department Library has been rejected.
        
        If you believe this is a mistake or would like to submit a new request with updated information,
        please feel free to register again.
        
        Best regards,
        SSN IT Department Library Team
        """
        
        message.attach(MIMEText(body, "plain"))
        
        try:
            # Create SMTP session and send email
            server = smtplib.SMTP("smtp.gmail.com", 587)
            server.starttls()
            server.login(sender_email, password)
            server.sendmail(sender_email, user_result.email, message.as_string())
            server.quit()
        except Exception as e:
            print(f"Error sending rejection email: {str(e)}")
            # Continue with the rejection process even if email fails
        
        db.session.commit()
        return redirect(url_for('admin_pending'))
        
    except Exception as e:
        db.session.rollback()
        print(f"Error rejecting user: {str(e)}")
        return jsonify({'error': str(e)}), 500

def send_email_due(to_email, subject, body):
    msg = EmailMessage()
    msg['From'] = "itlibrary377@gmail.com"
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.set_content(body)

    with smtplib.SMTP('smtp.gmail.com', 587) as server:
        server.starttls()
        server.login("itlibrary377@gmail.com", "vgbg hynz qjgk qxoo")  # 🔐 Use environment variable in production
        server.send_message(msg)

# Route to send reminders for overdue or due-soon books
@app.route('/admin/due_books', methods=['POST'])
def send_due_books_reminder():
    try:
        data = request.get_json()
        if not data or 'user_email' not in data:
            return jsonify({'error': 'Missing user_email'}), 400

        user_email = data['user_email']

        # ✅ Fetch due book details from the 'due_books' table
        result = db.session.execute(
            text("""
                SELECT "Title", "OverdueDate", "Status"
                FROM overdue_books
                WHERE useremail = :user_email AND status IN ('On Time', 'Overdue', 'Borrowed')
            """),
            {'user_email': user_email}
        ).mappings().fetchall()  # ✅ Convert result to list of dicts

        if result:
            # ✅ Filter for overdue and due-soon books
            overdue_books = []
            due_soon_books = []

            for row in result:
                # Check if book is overdue
                if row['status'] == 'Overdue':
                    overdue_books.append(f"- {row['title']} (Overdue, Due: {row['due_date'].strftime('%Y-%m-%d')})")
                # Check if book is due soon (within 3 days)
                elif row['status'] == 'On Time' and row['due_date'] and row['due_date'] < datetime.now() + timedelta(days=3):
                    due_soon_books.append(f"- {row['title']} (Due Soon, Due: {row['due_date'].strftime('%Y-%m-%d')})")

            # Combine overdue and due-soon books
            books_list = "\n".join(overdue_books + due_soon_books)
            if not books_list:
                return jsonify({'message': 'No overdue or due soon books to remind'}), 404

            subject = 'Book Due Date Reminder'
            body = f"Please return the following books by their due dates:\n{books_list}"
            send_email_due(user_email, subject, body)

            return jsonify({'message': 'Reminder sent successfully'})
        else:
            return jsonify({'error': 'No issued books found for this user'}), 404

    except Exception as e:
        print(f"Error in send_due_books_reminder: {str(e)}")
        return jsonify({'error': f'Internal server error: {str(e)}'}), 500
    
@app.route('/test-db-structure')
def test_db_structure():
    try:
        with db.engine.connect() as connection:
            # Get table structure
            result = connection.execute("""
                SELECT column_name, data_type 
                FROM information_schema.columns 
                WHERE table_name = 'student_requested_books';
            """)
            columns = [dict(row) for row in result]
            return jsonify(columns)
    except Exception as e:
        return str(e)


@app.route('/debug/cart', methods=['GET'])
def debug_cart():
    try:
        cart_items = session.get('cart', [])
        return jsonify({
            "cart_items": cart_items,
            "session_data": dict(session),
            "database_connection": str(db.engine.url),
            "table_exists": db.engine.dialect.has_table(db.engine, 'student_requested_books')
        })
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/debug/cart-state')
def debug_cart_state():
    try:
        cart = session.get('cart', [])
        return jsonify({
            'cart_items': cart,
            'cart_length': len(cart),
            'session_id': session.get('_id', None),
            'user': session.get('username', None)
        })
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/debug/checkout-test')
def debug_checkout_test():
    try:
        # Test database connection
        db.session.execute('SELECT 1')
        
        # Test table existence
        table_exists = db.engine.dialect.has_table(db.engine, 'student_requested_books')
        
        # Get table structure
        columns = []
        if table_exists:
            result = db.session.execute("""
                SELECT column_name, data_type 
                FROM information_schema.columns 
                WHERE table_name = 'student_requested_books';
            """)
            columns = [dict(row) for row in result]
        
        return jsonify({
            "database_connected": True,
            "table_exists": table_exists,
            "table_columns": columns,
            "current_cart": session.get('cart', []),
            "session_id": session.get('_id', None)
        })
    except Exception as e:
        return jsonify({
            "error": str(e),
            "database_connected": False
        })

@app.route('/debug/table-info')
def debug_table_info():
    try:
        # Get table structure
        result = db.session.execute("""
            SELECT 
                column_name, 
                data_type,
                column_default,
                is_nullable
            FROM information_schema.columns 
            WHERE table_name = 'student_requested_books'
            ORDER BY ordinal_position;
        """)
        
        # Get sequence information
        seq_info = db.session.execute("""
            SELECT * FROM information_schema.sequences
            WHERE sequence_name = 'student_requested_books_requestid_seq';
        """)
        
        return jsonify({
            "columns": [dict(row) for row in result],
            "sequence": [dict(row) for row in seq_info]
        })
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/debug/table-structure')
def debug_table_structure():
    try:
        result = db.session.execute(text("""
            SELECT 
                column_name, 
                data_type, 
                column_default, 
                is_nullable
            FROM information_schema.columns 
            WHERE table_name = 'student_requested_books'
            ORDER BY ordinal_position;
        """))
        
        columns = [dict(row) for row in result]
        
        return jsonify({
            "table_structure": columns,
            "table_exists": True
        })
    except Exception as e:
        return jsonify({
            "error": str(e),
            "table_exists": False
        })

@app.route('/debug/db-check')
def debug_db_check():
    try:
        # Check table structure
        table_info = db.session.execute(text("""
            SELECT column_name, column_default, data_type, is_nullable
            FROM information_schema.columns
            WHERE table_name = 'student_requested_books'
            ORDER BY ordinal_position;
        """)).fetchall()
        
        # Check if any records exist
        record_count = db.session.execute(text("""
            SELECT COUNT(*) FROM student_requested_books;
        """)).scalar()
        
        # Check sequence information
        sequence_info = db.session.execute(text("""
            SELECT * FROM information_schema.sequences
            WHERE sequence_name LIKE '%student_requested_books%';
        """)).fetchall()
        
        return jsonify({
            "table_structure": [dict(row) for row in table_info],
            "record_count": record_count,
            "sequence_info": [dict(row) for row in sequence_info]
        })
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/debug/issued-books')
def debug_issued_books():
    try:
        # Check if table exists
        table_exists = db.session.execute(text("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = 'issued_books'
            )
        """)).scalar()
        
        if not table_exists:
            return jsonify({
                'error': 'Table does not exist',
                'table_exists': False
            })
        
        # Get table structure
        structure_result = db.session.execute(text("""
            SELECT column_name, data_type, is_nullable
            FROM information_schema.columns
            WHERE table_name = 'issued_books'
            ORDER BY ordinal_position
        """))
        
        # Convert structure to list of dictionaries
        structure = []
        for row in structure_result:
            structure.append({
                'column_name': row[0],
                'data_type': row[1],
                'is_nullable': row[2]
            })
        
        # Get all records
        records_result = db.session.execute(text("""
            SELECT * FROM issued_books
            ORDER BY issue_date DESC
        """))
        
        # Convert records to list of dictionaries
        records = []
        for row in records_result:
            record = {}
            for idx, column in enumerate(records_result.keys()):
                record[column] = row[idx]
            records.append(record)
        
        # Get current user's email from session
        user_email = session.get('email')
        
        # Get records for current user
        user_records = []
        if user_email:
            user_records_result = db.session.execute(text("""
                SELECT * FROM issued_books
                WHERE useremail = :user_email
                ORDER BY issue_date DESC
            """), {'user_email': user_email})
            
            # Convert user records to list of dictionaries
            for row in user_records_result:
                record = {}
                for idx, column in enumerate(user_records_result.keys()):
                    record[column] = row[idx]
                user_records.append(record)
        
        return jsonify({
            'table_exists': True,
            'structure': structure,
            'total_records': records,
            'user_records': user_records,
            'current_user': user_email
        })
        
    except Exception as e:
        return jsonify({
            'error': str(e)
        })

@app.route('/debug/issued-books-table')
def debug_issued_books_table():
    try:
        # Check if table exists
        table_exists = db.session.execute(text("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = 'issued_books'
            )
        """)).scalar()
        
        if not table_exists:
            return jsonify({
                'error': 'Table does not exist',
                'table_exists': False
            })
        
        # Get table structure
        structure_result = db.session.execute(text("""
            SELECT column_name, data_type, is_nullable
            FROM information_schema.columns
            WHERE table_name = 'issued_books'
            ORDER BY ordinal_position
        """))
        
        # Convert structure to list of dictionaries
        structure = []
        for row in structure_result:
            structure.append({
                'column_name': row[0],
                'data_type': row[1],
                'is_nullable': row[2]
            })
        
        # Get all records
        records_result = db.session.execute(text("""
            SELECT * FROM issued_books
            ORDER BY issue_date DESC
        """))
        
        # Convert records to list of dictionaries
        records = []
        for row in records_result:
            record = {}
            for idx, column in enumerate(records_result.keys()):
                record[column] = row[idx]
            records.append(record)
        
        return jsonify({
            'table_exists': True,
            'structure': structure,
            'records': records
        })
        
    except Exception as e:
        return jsonify({
            'error': str(e)
        })

# ✅ Run Flask Server on http://127.0.0.1:5000
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)