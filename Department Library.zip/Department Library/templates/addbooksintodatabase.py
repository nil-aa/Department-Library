

import pandas as pd
import psycopg2
from datetime import datetime

# Step 1: Load Excel file
excel_file = r"C:\Users\Nikhil\Downloads\SSN\College Files\Second Year\4th Semester\ADSA Project\janfjanfj\TrieAutocomplete\NilaaADSA\TrieAutocomplete Updated\TrieAutocomplete 4\TrieAutocomplete\templates\department_library_users.xlsx"  # 🔁 Update this path
  # 🔁 Update this path
df = pd.read_excel(excel_file)

# Step 2: Connect to PostgreSQL
conn = psycopg2.connect(
    dbname="dept_lib",
    user="postgres",
    password="Rajini",
    host="localhost",
    port="5432"
)
cursor = conn.cursor()



# Step 3: Create the users table if it doesn't exist
create_table_query = '''
CREATE TABLE IF NOT EXISTS hashusers (
    user_id VARCHAR(20) PRIMARY KEY,
    user_name TEXT,
    email TEXT,
    password TEXT,
    contact_number VARCHAR(15),
    date_of_birth DATE,
    age INTEGER,
    role TEXT,
    account_creation_date DATE
);
'''
cursor.execute(create_table_query)
conn.commit()

# Step 4: Insert rows safely
for index, row in df.iterrows():
    try:
        cursor.execute("""
            INSERT INTO hashusers (
                user_id, user_name, email, password, contact_number,
                date_of_birth, age, role, account_creation_date
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (user_id) DO NOTHING;
        """, (
            str(int(float(row['User ID']))),  # Remove scientific notation
            row['User Name'],
            row['Email ID'],
            row['Password'],
            str(row['Contact Number']),
            pd.to_datetime(row['Date of Birth']).date(),
            int(row['Age']),
            row['Role'],
            pd.to_datetime(row['Account Creation Date']).date()
        ))
        conn.commit()  # ✅ Commit after each successful insert
    except Exception as e:
        conn.rollback()  # ❗ Rollback only the current failed transaction
        print(f"❌ Error at row {index+1}: {e}")

# Step 5: Close connection
cursor.close()
conn.close()

print("✅ User data import complete!")
