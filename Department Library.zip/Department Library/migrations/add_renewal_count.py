"""add renewal count

Revision ID: add_renewal_count
Revises: 
Create Date: 2024-03-19 10:00:00.000000

"""
import alembic
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = 'add_renewal_count'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    # Add renewal_count column to issued_books table
    alembic.op.add_column('issued_books', sa.Column('renewal_count', sa.Integer(), server_default='0', nullable=False))

def downgrade():
    # Remove renewal_count column from issued_books table
    alembic.op.drop_column('issued_books', 'renewal_count') 