from flask import Flask, render_template, request, jsonify
from models import db, Book  # assuming your models are in models.py

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///books.db'  # update with your DB
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

@app.route('/delete-book', methods=['GET', 'POST'])
def delete_book():
    if request.method == 'POST':
        book_id = request.form.get('BookID')
        isbn = request.form.get('ISBN')

        if not book_id and not isbn:
            return jsonify({
                'status': 'error',
                'message': 'Please provide either Book ID or ISBN.'
            })

        book = None

        # Try by BookID
        if book_id:
            try:
                book = Book.query.filter_by(BookID=int(book_id)).first()
            except ValueError:
                return jsonify({
                    'status': 'error',
                    'message': 'Invalid Book ID format.'
                })

        # If not found, try by ISBN
        if not book and isbn:
            book = Book.query.filter_by(ISBN=isbn).first()

        if book:
            db.session.delete(book)
            db.session.commit()
            return jsonify({
                'status': 'success',
                'message': f'Book "{book.Title}" deleted successfully.'
            })
        else:
            return jsonify({
                'status': 'error',
                'message': 'Book not found.'
            })

    return render_template('delete_book.html')
