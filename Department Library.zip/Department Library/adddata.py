import pandas as pd
from sqlalchemy import create_engine, text
from datetime import datetime

# PostgreSQL connection URI
DATABASE_URI = "postgresql://postgres:Rajini@localhost:5432/dept_lib"
engine = create_engine(DATABASE_URI)

# Load Excel data
df = pd.read_excel(r'C:\Users\Nikhil\Downloads\SSN\College Files\Second Year\4th Semester\ADSA Project\janfjanfj\TrieAutocomplete\NilaaADSA\TrieAutocomplete\static\department_library_students_requested_books.xlsx') 
df.rename(columns={'Request-Date': 'Request_Date'}, inplace=True)

# Convert Request_Date to proper date format
df['Request_Date'] = pd.to_datetime(df['Request_Date'], errors='coerce').dt.date

# === Add the logged-in user's email ===
user_email = "student@ssn.edu.in"  # Replace this with actual session user email
df['EmailID'] = user_email

# === Lookup BookID for each ISBN ===
book_ids = {}
with engine.connect() as conn:
    for isbn in df['ISBN'].unique():
        result = conn.execute(
            text("SELECT BookID FROM book WHERE ISBN = :isbn"),
            {"isbn": isbn}
        ).fetchone()
        book_ids[isbn] = result[0] if result else None

# Add BookID column to the dataframe
df['BookID'] = df['ISBN'].map(book_ids)

# Reorder and filter columns
df_to_insert = df[[
    'BookID', 'ISBN', 'Title', 'Author', 'Category',
    'Publication', 'Request_Purpose', 'Request_Date', 'Status', 'EmailID'
]]

# Write to PostgreSQL
df_to_insert.to_sql(
    name='student_requested_books',
    con=engine,
    if_exists='append',
    index=False
)

print("✅ Data with EmailID and BookID successfully inserted into student_requested_books!")
